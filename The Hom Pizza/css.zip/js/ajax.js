﻿$(document).ready(function () {
    $(".deleteCart, .deleteCart2").click(function (e) {
        e.preventDefault();

        let button = $(this);
        let idsp = button.data("id");
        let idpizza = button.data("idpizza");

        $.ajax({
            url: "/Cart/RemoveFromCart",
            type: "POST",
            data: { idsp: idsp, idpizza: idpizza },
            success: function (response) {
                if (response.success) {
                    // Xóa dòng sản phẩm khỏi bảng
                    let row = button.closest("tr");
                    row.fadeOut(200, function () {
                        $(this).remove();
                    });
                    location.reload();
                } else {
                    location.reload();
                    Swal.fire({
                        title: "Lỗi!",
                        text: response.message,
                        icon: "error",
                        toast: true,
                        position: "top-end",
                        showConfirmButton: false,
                        timer: 2000
                    });
                }
            },
            error: function () {
                Swal.fire({
                    title: "Lỗi!",
                    text: "Có lỗi xảy ra, vui lòng thử lại!",
                    icon: "error",
                    toast: true,
                    position: "top-end",
                    showConfirmButton: false,
                    timer: 2000
                });
            }
        });
    });

    // Khi người dùng nhấn quay lại trang trước, reload để cập nhật giỏ hàng
    $(window).on("pageshow", function (event) {
        if (event.originalEvent.persisted) {
            location.reload();
        }
    });
});

