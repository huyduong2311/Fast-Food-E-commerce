﻿document.addEventListener("DOMContentLoaded", function () {
    let slider = document.querySelector(".slider-list");
    let slides = document.querySelectorAll(".slider-item");
    let index = 0;
    let slideWidth; // Declare slideWidth outside the function

    function updateSlideWidth() { // Function to get correct width on resize
        slideWidth = slides[0].offsetWidth;
    }

    updateSlideWidth(); // Initial calculation
    window.addEventListener('resize', updateSlideWidth); // Recalculate on resize


    document.querySelector(".prev").addEventListener("click", function () {
        changeSlide(-1);
    });
    document.querySelector(".next").addEventListener("click", function () {
        changeSlide(1);
    });

    function changeSlide(n) {
        index += n;
        if (index >= slides.length) {
            index = 0;
        } else if (index < 0) {
            index = slides.length - 1;
        }
        updateSlider();
    }

    function updateSlider() {
        slider.style.transform = `translateX(-${index * slideWidth}px)`;
    }

    setInterval(() => changeSlide(1), 3000);
});